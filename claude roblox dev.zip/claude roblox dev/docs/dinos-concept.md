# DINO DICE — Fiches concept des 28 dinos

Source des données : `src/shared/Config/Dinos.luau` (id, rareté, archétype).
Tout est **inventé** : style cartoon chunky et mignon-cool, grosse tête, couleurs vives, silhouette lisible à 30 studs.
Plus la rareté monte, plus la silhouette est spectaculaire (Secret = effets glitch / cosmiques).

**Taille relative** : 1,0 = base de l'archétype (Théropode commun ≈ 4 studs de haut).
**Couleurs** : principale / secondaire / accent (l'accent sert aussi aux parties émissives).
**Émissif** : parties en matériau Neon côté Roblox (ou couleur émissive dans la texture).

---

## Commun

### Galetosaure — Quadrupède — taille 0,9
- Silhouette : corps tout rond comme un galet, pattes très courtes, cou court, petites bosses lisses sur le dos.
- Couleurs : `#9AA5B1` / `#D9D4C7` / `#7BC67E`
- Émissif : aucun.
- Personnalité (Idle) : somnolent ; paupières qui tombent, se rendort, ronflement (dos qui gonfle).

### Moussecrête — Théropode — taille 0,9
- Silhouette : crête de mousse en touffe ronde sur la tête, ventre clair, queue courte et dodue.
- Couleurs : `#5DBB63` / `#F2E8C9` / `#2E7D32`
- Émissif : aucun.
- Personnalité : timide et flatté ; se dandine, se cache le museau, la crête frétille.

### Brindilraptor — Théropode — taille 0,85
- Silhouette : raptor fin, 2 brindilles plantées en plumes sur la nuque et la queue, griffes visibles.
- Couleurs : `#B5835A` / `#F3D9A4` / `#6D9B3A`
- Émissif : aucun.
- Personnalité : maniaque ; compte (hoche la tête 3 fois), regarde à gauche à droite.

## Peu commun

### Flaquodon — Aquatique — taille 0,8
- Silhouette : petit, très rond, gros yeux, nageoires courtes, queue en spatule, gouttelette sur le front.
- Couleurs : `#4FC3F7` / `#E1F5FE` / `#0288D1`
- Émissif : la goutte du front, léger.
- Personnalité : susceptible ; gonfle les joues, se retourne vexé puis revient.

### Sablegriffe — Théropode — taille 1,0
- Silhouette : grandes griffes de pelle aux bras, bandeau de rayures sur le dos, museau carré.
- Couleurs : `#E8C07D` / `#C68B4E` / `#FF7043`
- Émissif : aucun.
- Personnalité : sportif ; boxe dans le vide, sautille sur place.

### Boucératops — Quadrupède — taille 1,1
- Silhouette : collerette ronde avec 3 cornes (2 au front, 1 au nez), une chaussette accrochée à une corne.
- Couleurs : `#FFB74D` / `#FFF3E0` / `#8D6E63`
- Émissif : aucun.
- Personnalité : bon vivant ; secoue la tête (la chaussette balance), gratte le sol.

## Rare

### Braisedos — Quadrupède — taille 1,15
- Silhouette : 2 rangées de plaques dorsales en losange, queue à 2 pointes.
- Couleurs : `#C62828` / `#4E342E` / `#FFB300`
- Émissif : bords des plaques orange-braise, pulsation lente.
- Personnalité : chaleureux ; s'étire comme un chat, petites étincelles quand il souffle.

### Givrecroc — Théropode — taille 1,05
- Silhouette : crête de pics de glace sur la tête et le dos, crocs bleus qui dépassent, écharpe de givre.
- Couleurs : `#B3E5FC` / `#FFFFFF` / `#4FC3F7`
- Émissif : pics de glace, bleu pâle.
- Personnalité : enrhumé ; frissonne, éternue (recul de tête + flocons).

### Lianoptéryx — Ptérosaure — taille 1,0
- Silhouette : ailes en feuilles géantes, lianes enroulées aux poignets, crête en feuille recourbée.
- Couleurs : `#43A047` / `#C5E1A5` / `#FFEB3B`
- Émissif : aucun.
- Personnalité : acrobate ; se balance d'une patte sur l'autre, ailes repliées comme une cape.

### Ronceplaque — Quadrupède — taille 1,1
- Silhouette : dos couvert d'épines en ronces, queue en massue épineuse, petits yeux tristes.
- Couleurs : `#6A1B9A` / `#A5D6A7` / `#E91E63`
- Émissif : petites baies au bout des épines, rose.
- Personnalité : câlin frustré ; tend la tête vers le joueur, soupire, baisse les épaules.

## Épique

### Orageceros — Quadrupède — taille 1,25
- Silhouette : une très longue corne en éclair zigzag sur le nez, crinière de nuage gris sur la nuque.
- Couleurs : `#37474F` / `#90A4AE` / `#FFEE58`
- Émissif : corne jaune électrique, arcs qui crépitent.
- Personnalité : nerveux ; sursaute, la crinière se hérisse, regarde le ciel.

### Cristalodon — Aquatique — taille 1,2
- Silhouette : rangée de cristaux le long du dos, nageoires taillées en facettes, queue diamant.
- Couleurs : `#7E57C2` / `#E1BEE7` / `#80DEEA`
- Émissif : cristaux cyan, scintillement.
- Personnalité : élégant ; ondule lentement, petite pirouette sur lui-même.

### Volcanokéros — Quadrupède — taille 1,35
- Silhouette : cratère fumant sur le dos, 2 cornes de roche, pattes comme des colonnes de basalte.
- Couleurs : `#3E2723` / `#5D4037` / `#FF5722`
- Émissif : fissures de lave sur le corps + bouche du cratère + naseaux.
- Personnalité : joyeux ; souffle des ronds de fumée par le nez, frétille de la queue.

### Abyssaure — Aquatique — taille 1,3
- Silhouette : longue mâchoire, antenne-lanterne au front, nageoires frangées, gros yeux ronds.
- Couleurs : `#1A237E` / `#283593` / `#00E5FF`
- Émissif : lanterne + points lumineux sur les flancs.
- Personnalité : fêtard des profondeurs ; balance sa lanterne comme une boule à facettes.

## Légendaire

### Éclipsaurus — Théropode — taille 1,4
- Silhouette : anneau solaire (halo d'éclipse) fixé derrière la tête, crête en croissant, queue longue fine.
- Couleurs : `#212121` / `#FFD54F` / `#FFF8E1`
- Émissif : contour de l'anneau doré (couronne solaire).
- Personnalité : majestueux ; lève le menton, l'anneau tourne lentement.

### Ambrelion — Théropode — taille 1,4
- Silhouette : grosse crinière de pointes d'ambre autour du cou, queue à touffe, pattes musclées.
- Couleurs : `#FF8F00` / `#FFE082` / `#6D4C41`
- Émissif : pointes d'ambre translucides (3 petits points noirs dedans).
- Personnalité : fier ; secoue sa crinière, écoute ses moustiques (tête penchée).

### Tonnerrex — Théropode — taille 1,5
- Silhouette : T-rex massif, 2 cornes-paratonnerres, rayures en zigzag, queue en éclair.
- Couleurs : `#1565C0` / `#0D47A1` / `#FFFF00`
- Émissif : rayures et cornes, éclairs intermittents.
- Personnalité : bruyant ; ouvre la gueule, rien ne sort... puis rugit avec 1 s de retard.

### Aurorasaure — Ptérosaure — taille 1,45
- Silhouette : très grandes ailes dégradées, longue crête en ruban, queue à rubans flottants.
- Couleurs : `#00BFA5` / `#7C4DFF` / `#F48FB1`
- Émissif : membranes des ailes (dégradé vert-violet-rose qui ondule).
- Personnalité : timide-coquet ; déploie les ailes quand on le regarde, les replie sinon.

## Mythique

### Nébulodon — Aquatique — taille 1,6
- Silhouette : corps translucide de nébuleuse, nageoires en voiles de gaz, étoiles incrustées, queue en comète.
- Couleurs : `#311B92` / `#E040FB` / `#FFFFFF`
- Émissif : étoiles + bord des nageoires + traînée de queue.
- Personnalité : rêveur ; flotte en l'air, croque une étoile, regard perdu.

### Chronoraptor — Théropode — taille 1,5
- Silhouette : cadran d'horloge sur le flanc, crête en aiguilles, sablier sur le bout de queue, rouages aux épaules.
- Couleurs : `#B0BEC5` / `#FFD700` / `#00E5FF`
- Émissif : cadran et sablier cyan, aiguilles qui tournent.
- Personnalité : pressé ; regarde son flanc-horloge, tape du pied, sursaute.

### Magmaroi — Quadrupède — taille 1,75
- Silhouette : couronne de lave refroidie, cape de roche sur les épaules, plaques de basalte, cou dressé fier.
- Couleurs : `#212121` / `#BF360C` / `#FFAB00`
- Émissif : pointes de la couronne + veines de magma entre les plaques.
- Personnalité : royal et capricieux ; lève le nez, frappe le sol d'une patte, attend qu'on s'incline.

### Spectrosaure — Ptérosaure — taille 1,6
- Silhouette : ailes déchirées en lambeaux fantômes, crête en voile, pas de pattes visibles (bas du corps en traîne).
- Couleurs : `#CFD8DC` / `#80CBC4` / `#B388FF`
- Émissif : tout le corps semi-transparent + yeux violets.
- Personnalité : farceur ; disparaît/réapparaît (clignotement), fait « bouh » en ouvrant les ailes.

## Primordial

### Titanomarbre — Quadrupède — taille 2,0
- Silhouette : colosse sculpté, colonnes antiques comme pattes, socle sous les pieds, veines dorées, cornes en volutes.
- Couleurs : `#F5F5F5` / `#BDBDBD` / `#FFD700`
- Émissif : veines dorées, lueur lente.
- Personnalité : poseur ; prend une pose de statue, la tient, change de pose.

### Solaripteryx — Ptérosaure — taille 1,9
- Silhouette : ailes en rayons de soleil (bord dentelé en flammes), crête-disque solaire, longue queue de feu.
- Couleurs : `#FFC107` / `#FF6F00` / `#FFFDE7`
- Émissif : crête-disque + bord des ailes + queue (flammes).
- Personnalité : leader matinal ; bat des ailes, pointe le bec vers le ciel, s'étire.

### Gaïatops — Quadrupède — taille 2,2
- Silhouette : une petite forêt (3 arbres + champignons) sur le dos, collerette en racines, cornes en bois de cerf.
- Couleurs : `#795548` / `#4CAF50` / `#FF80AB`
- Émissif : champignons roses lumineux, lucioles.
- Personnalité : sereine ; respire lentement, les arbres se balancent, un oiseau se pose.

### Léviathodon — Aquatique — taille 2,4
- Silhouette : immense, mâchoire géante, nageoires-ailes, plaques d'armure abyssales, vortex d'eau autour de la queue.
- Couleurs : `#004D40` / `#00838F` / `#64FFDA`
- Émissif : runes-marées sur les plaques + gorge quand il bâille.
- Personnalité : flegmatique ; bâille énormément (gueule grande ouverte), l'eau tourbillonne.

## Secret

### Glitchosaure — Théropode — taille 1,6
- Silhouette : corps en blocs voxels décalés, morceaux qui flottent détachés (queue en cubes), un œil pixel.
- Couleurs : `#FF00FF` / `#00FF00` / `#000000`
- Émissif : tout le corps, effet « glitch » RGB (décalage de couleurs, frames qui sautent).
- Personnalité : instable ; se téléporte de quelques studs, se fige, saccade, « T-pose » une fraction de seconde.

### Omégarex — Théropode — taille 2,5
- Silhouette : T-rex cosmique, couronne de cornes en galaxie, symbole Ω flottant au-dessus de la tête, queue qui se dissout en étoiles, anneaux d'orbite.
- Couleurs : `#0D0221` / `#7B1FA2` / `#FFD740`
- Émissif : symbole Ω + yeux + motifs d'étoiles qui défilent sur la peau (texture ciel cosmique).
- Personnalité : boss final ; regarde le joueur de haut, croise les petits bras, rugit en faisant trembler l'écran.
