# Dino RNG — Map + Biome install notes

## Already in Studio
- ReplicatedStorage/Shared/{Config,BiomeData,BiomeClientState}
- ReplicatedStorage/Remotes/BiomeRemotes/{RequestUnlock,RequestTeleport,BiomeStateChanged}
- ServerScriptService/{Main,Services/BiomeService}
- StarterPlayer/StarterPlayerScripts/BiomeController
- Workspace/Hub + Workspace/Biomes (20 islands)

## Full MapBuilder source
Local path: `src/ServerStorage/Tools/MapBuilder.luau`
Paste into `ServerStorage/Tools/MapBuilder` (ModuleScript), then in the Studio command bar:

```lua
require(game.ServerStorage.Tools.MapBuilder).build()
```

The place already has a lighter runtime-built map (same layout, lighter decor). Re-running the full MapBuilder rebuilds Hub + Biomes with ~250 decor parts per biome.

## Monnaie Fossiles — place Studio « jeux premier » (2026-10-19)
Ce code vit directement dans Studio (modifié via le MCP), pas dans `src/` ni `build/`.
Pièces → **Fossiles** (monnaie principale), anciens Fossiles → **Os** (🦴). Migration DataVersion 2.
Sauvegarde des scripts d'avant : `ServerStorage/Backup_AvantFossiles` (désactivés, à supprimer une fois validé).
Jest ne tourne qu'avec le flag Studio `FFlagEnableLoadModule = true`.

Tests à faire en jeu :
1. En Studio : le compteur en haut à gauche affiche 100 K au départ ; le leaderboard affiche « Fossiles ».
2. Poser un dino : le nombre défile doucement chaque seconde, pas de chiffres qui volent.
3. L'icône pulse au plus une fois toutes les 5 s.
4. Survol (PC) ou toucher (mobile) du compteur : « +X/s » gris apparaît, puis disparaît.
5. Acheter une amélioration : petite gerbe d'éclats dorés aux pieds, le compteur baisse.
6. Acheter sans assez de Fossiles (ex. monter un socle) : le compteur tremble et vire au rouge pâle 0,3 s.
7. Vendre un gros lot de dinos (gain ≥ 10 % du solde) : popup « +X 🐚 » centré 2 s puis fondu.
8. Toutes les 8–12 s avec un revenu > 0 : un petit éclat doré monte du joueur.
9. Relances d'Instinct, échanges, packs, quêtes, Volcan : affichent et utilisent bien les **Os**.
10. Jeu publié : revenir après une absence → popup hors ligne = min(absence, 8 h) × revenu/s × 0,5.
11. Jeu publié, ancien profil : Pièces devenues Fossiles, anciens Fossiles devenus Os.
12. Rebirth : tous les Fossiles sont dépensés, le reste est gardé.

## Playtest checklist
1. Unlock biomes in order only
2. Double-click unlock spam (should not double-spend)
3. Teleport to locked biome (denied)
4. Leave mid-unlock
5. Rejoin and spawn in current biome
