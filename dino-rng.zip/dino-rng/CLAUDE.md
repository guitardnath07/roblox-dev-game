# Dino RNG — règles du projet

## Où est le vrai jeu
- **Le jeu, c'est la place Studio « jeux premier »** (placeId 136768095215169), synchronisée par **Rojo** avec `jeux-premier/`.
  - `jeux-premier/default.project.json` gère 4 dossiers : `src/server` → ServerScriptService.Server, `src/tests` → ServerScriptService.Tests,
    `src/shared` → ReplicatedStorage.Shared, `src/client` → StarterPlayer.StarterPlayerScripts.Client.
  - `$ignoreUnknownInstances` : Rojo ne supprime jamais le reste (carte, paquets ProfileStore / Jest, ServerStorage).
  - Lancer : `cd jeux-premier && rojo serve` (port 34872), puis **Connect** dans le plugin Rojo de Studio.
  - **Modifier les fichiers, pas Studio** : une modif faite à la main dans Studio sur ces scripts est écrasée.
- `src/`, `build/`, `INSTALL_MAP.md` (sections biomes) à la racine = **ancienne version** (20 biomes, BiomeService, StackKey).
  Elle n'est PAS dans la place. Ne jamais la synchroniser ni s'en inspirer comme si c'était le jeu.
- Le MCP Roblox Studio sert à : Play, console, captures, inspecter la place. Pas à éditer les scripts gérés par Rojo.

## Le jeu
Roblox « Dino RNG » : on lance un dé, le serveur tire un dino. Ses dinos posés sur des socles rapportent des Fossiles chaque seconde.
- 28 espèces (`Config/Dinos`, `oneIn` croissant), 8 raretés : Commun, Peu commun, Rare, Épique, Légendaire, Mythique, Primordial, Secret.
- Mutations fixées au tirage : tailles (Bébé, Normal, Géant, Colossal) et peaux (Normale, Ambre, Jade, Obsidienne, Or fossile, Arc-en-ciel).
- Par dino, relançables : Instinct (Os), Grade (Ambre), Empreinte (Fossiles, dès le rebirth 5).
- Progression : 14 dés (Boutique), arbre d'améliorations, niveaux de socles, rebirth, reliques (Volcan des Défis, 100 étages).
- Social : échanges, annonces des tirages rares (tous serveurs), classements, quêtes (Tickets), codes, récompenses quotidiennes.

## Monnaies (profil, `server/Data/Template.luau`)
| Champ | Nom affiché | Rôle |
|---|---|---|
| `Fossils` 🐚 | Fossiles | Monnaie principale : revenu passif, dés, améliorations, socles, rebirth, Empreintes. Modifiée UNIQUEMENT par `CurrencyService` (sauf gains hors ligne au chargement). |
| `Bones` 🦴 | Os | Relances d'Instinct, échanges, packs Robux, quêtes, Volcan. (S'appelait « Fossils » avant la migration v2.) |
| `Amber` 🔶 | Ambre | Relances de Grade ; pastilles au sol, Volcan, paliers d'encyclopédie. |
| `GoldenRolls`, `Tickets` | Lancers Dorés, Tickets | Lancer sans délai ; boutique de quêtes. |
Les identifiants internes `coinsMultiplier`, `coinsBonus`, `coins_potion`, `coins_1..6` sont restés : ils sont dans les sauvegardes. Ne pas renommer.

## Carte des fichiers (`jeux-premier/src`)
- `server/init.server.luau` : charge tous les modules de `Services/`, `Init()` puis `Start()`. Un service = un fichier, rien à déclarer ailleurs.
- `server/Services/` : `DataService` (ProfileStore, migrations, réplication `DataSync`, leaderstats, hors ligne), `CurrencyService` (Add/Spend/Get des Fossiles),
  `IncomeService` (tick 1 s), `RollService`, `LuckService` (chance totale + détail), `InventoryService` (sac, vente, verrou, gel en échange),
  `PlotService` (parcelles, socles), `ProgressionService` (dés, arbre, rebirth), `RerollService`, `TradeService`, `QuestService`, `RewardsService`,
  `MonetizationService` (seul ProcessReceipt), `GamepassService`, `PolicyService`, `AnnounceService`, `LeaderboardService`, `EventService`,
  `FriendService`, `AmberPickupService`, `VolcanoService`, `DevService` (Studio uniquement : DevGrant, DevGrantDino).
- `server/Data/` : logique pure testable — `Migrations`, `Template`, `OfflineEarnings`, `Purchases`, `TradeLogic`, `RateLimit`, `VolcanoCombat`.
- `shared/` : `Odds` (chances, partagé serveur/client), `Bonuses` (calcul pur des bonus/revenus), `Types`, `Net/Remotes` (TOUS les remotes), `Config/*` (tout l'équilibrage).
- `client/init.client.luau` : charge tous les `Controllers/`. `UI/Kit` + `UI/Theme` = style unique (parchemin / pierre), `UI/Window` = fenêtre modale,
  `UI/Screens/*` = un écran par fichier, ouvert par `UIController:Open("Nom")`. `UI/RollReveal` = révélation (arène 3D pour Épique+),
  `UI/DinoView` = modèle 3D d'un dino (`ReplicatedStorage.Assets.Dinos.<modelName>`, sinon cube de repli).
- `tests/` : Jest-Lua. `require(game.ServerScriptService.Tests.RunTests)()` pendant un Play ; nécessite le flag Studio `FFlagEnableLoadModule = true`.

## Règles techniques (toujours)
- Luau `--!strict`, commentaires en français, même style que le code voisin.
- **Le serveur décide de tout.** Le client envoie une intention ; le serveur vérifie, tire, calcule, sauvegarde. Aucune logique de jeu côté client.
- Chaque remote valide ses arguments (type, nil, NaN, infini, négatif, taille, appartenance de l'uuid) et passe par `RateLimit`.
- Tous les chiffres d'équilibrage dans `shared/Config/*`, jamais en dur dans les services. Tables de tirage en entiers sur 1 000 000, total exact.
- Les chances affichées viennent de `shared/Odds` / `Bonuses`, comme le serveur.
- Toute écriture de profil passe par `DataService:Update` / `Increment` (répliquée). Les Fossiles passent par `CurrencyService`.
- Nouveau champ de profil : l'ajouter à `Template` + `Types` ; changement de forme : `Migrations[v+1]` + monter `CURRENT_VERSION`.
- Une vérification (assert ou test Jest) pour toute logique d'argent, de hasard ou d'échange.
- Effets visuels : côté client, locaux au joueur, nettoyés par un Maid.
- Mobile d'abord : tailles en Scale, `UIAspectRatioConstraint`, boutons ≥ 44 px, `ScreenInsets`.

## Pièges connus
- `execute_luau` du MCP : `require()` y donne une COPIE des modules (pas de profils chargés) et ses threads meurent à la fin de l'appel.
  Pour tester un vrai flux, déclencher les remotes existants (`game.ReplicatedStorage.Remotes.X:FireClient(...)`).
- Le Play lancé par le MCP repasse parfois tout seul en mode Édition : revérifier l'état avant d'enchaîner.
- `ServerStorage.Backup_AvantFossiles` : copie désactivée d'avant la migration v2 ; à supprimer une fois validé.

## Fait le 2026-10-19 (session 2)
- Monnaies : barre fine en haut (CurrencyController), pièces 3D qui sortent des dinos posés (local au joueur).
- Boutons « bonbon » (Kit.button) + icônes 3D du HUD (`ReplicatedStorage.Assets.Icons`, dans la place uniquement).
- Profil (titres `Config/Titles`, dino vitrine, ProfileService) ; onglet Statistiques dans Réglages.
- Arbre d'améliorations refait : 52 cases / 12 catégories, Auto-Lancer à acheter, dés Or / Diamant / Arc-en-ciel (`treeOnly`),
  cases cachées tant que la voisine n'est pas achetée, fond Blender (`rbxassetid://122948084121708`).
- Sanctuaire du Phénix (ShrineService) : bouton Rebirth = téléportation, rebirth seulement au totem, cinématique `UI/RebirthCinematic`,
  phénix Blender reconstruit en pièces (`server/Data/PhoenixShape`, généré par `assets/blender/phoenix.py` + `phoenix_to_luau.py`),
  ailes animées (PhoenixController).
- Fenêtres style « cartoon » (`Window.open` option `style`, écran : `style = "cartoon"`) : Sac et Boutique.
- Blender 5.2.2 piloté en ligne de commande (pas de MCP Blender) ; scripts dans `jeux-premier/assets/blender/`.

## Reste à faire
0. Passer les autres écrans en style cartoon (Quêtes, Relances, Rebirth, Paléo, Échange, Reliques, choix du socle).
0. Corrections de VERIFICATION.md (Auto-Lancer freiné par les révélations, chances sans trèfles, courbe des rebirths…).
1. **Modèles 3D des 28 dinos** (+ dés), icônes, musiques, ciel : tout est `rbxassetid://0` ou cube de repli (`Config/Animations`, `Products`, `Gamepasses` ont aussi des IDs à 0).
2. Vérification complète (sécurité, duplication, chances, équilibrage, interface, perf) → `VERIFICATION.md`.
3. Optionnel : stations dans le Hub (ProximityPrompt) qui ouvrent les écrans existants (Boutique, Sac, Relances, Quêtes, Échange).
4. Optionnel : Ambre sous le compteur discret de Fossiles ; son court pour les effets de monnaie (`CURRENCY_FX.soundId`).
